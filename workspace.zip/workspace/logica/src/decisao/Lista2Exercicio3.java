package decisao;

import javax.swing.JOptionPane;

public class Lista2Exercicio3 {

	public static void main(String[] args) {
		
		int valor1 = Integer.parseInt(JOptionPane.showInputDialog("Valor 1"));
		int valor2 = Integer.parseInt(JOptionPane.showInputDialog("Valor 2"));
		char operador = JOptionPane.showInputDialog("Digite <+>, <->, <*> ou </>").charAt(0);
		//String operador = JOptionPane.showInputDialog("Digite <+>, <->, <*> ou </>");
		int resultado=0;
		//if (operador.equals("+")) {
		if (operador=='+') {
			resultado = valor1+valor2;
		}else if (operador=='-') {
			resultado = valor1-valor2;
		}else if (operador=='*') {
			resultado = valor1*valor2;
		}else if (operador=='/') {
			
			if (valor2!=0) { //se n�o for igual a zero
				resultado=valor1/valor2;
			}
			
		} else {
			System.out.println("Operador inv�lido");
		}
		System.out.println("Resultado: " + resultado);
		
		
		
		//System.out.println(valor1 + "\n" + valor2 + "\n" + valor3);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
