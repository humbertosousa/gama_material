package decisao;

import javax.swing.JOptionPane;

public class DesafioDecisaoSimples {

	public static void main(String[] args) {
		/*
		 * Ter� que inputar: nome de uma pessoa e a idade
		 * Dever� exibir uma das mensagens:
		 * maior que 70 anos, ou igual a 16 ou 17 => "Voto Facultativo"
		 * menor que 16 anos => "N�o vota"
		 * se estiver entre 18 e 70 => "Obrigado a votar"
		 * 
		 */
		
		//	idade==17
		
		String nome = JOptionPane.showInputDialog("Nome").toUpperCase();
		short idade = Short.parseShort(JOptionPane.showInputDialog("Idade"));
		
		if (idade<16) {
			System.out.println(nome + " voc� n�o pode votar.");
		}
		
		if (idade>=18 && idade<70) {
			System.out.println(nome + " voc� � obrigado a votar.");
		}
		
		if (idade==16 || idade==17 || idade>=70) {
			System.out.println(nome + " o seu voto � facultativo.");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
