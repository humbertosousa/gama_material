package variaveis;

import javax.swing.JOptionPane;

public class Carrinho {

	public static void main(String[] args) {
		/*
		 * Criem as variaveis para:
		 * - nome do produto
		 * - categoria do produto (alimenticio, eletrodomestico...)
		 * - valor do produto
		 * - qtde do produto
		 * - imposto do produto
		 */
		
		/*
		 * Exibam no final:
		 * - total sem imposto
		 * - total com imposto
		 * - s� o valor do imposto sobre o valor do produto
		 * - total com imposto e 10% de desconto (para os pagamentos a vista)
		 */
		String produto = JOptionPane.showInputDialog("Digite o produto");
		String categoria = JOptionPane.showInputDialog("Digite a categoria");
		double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor"));
		int qtde = Integer.parseInt(JOptionPane.showInputDialog("Qtde"));
		double imposto = Double.parseDouble(JOptionPane.showInputDialog("Imposto"));
		
		System.out.println("Produto...: " + produto);
		System.out.println("Categoria.: " + categoria);
		System.out.println("Valor.....: " + valor);
		System.out.println("Qtde......: " + qtde);
		System.out.println("Imposto...: " + imposto);
		
		double totalSemImposto = valor * qtde;
		double totalComImposto = totalSemImposto + totalSemImposto * (imposto/100);
		double valorImposto= valor * (imposto/100);
		//double totalVista = totalComImposto * 0.9;
		
		System.out.println("Total sem Imposto: " + totalSemImposto);
		System.out.println("Total com Imposto: " + totalComImposto);
		System.out.println("Valor Imposto: " + valorImposto);
		System.out.println("Total com Imposto (Vista): " + (totalComImposto * 0.9));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
