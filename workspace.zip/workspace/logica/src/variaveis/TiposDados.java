package variaveis;

import javax.swing.JOptionPane;

public class TiposDados {

	public static void main(String[] args) {
		
		/*
		 * Existem dois Tipos de Dados
		 * - alfanum�rico: � o dado que n�o vai ser utilizado em uma express�o matem�tica e 
		 * tamb�m n�o � um dado sens�vel (muito utilizado para buscas) para o modelo de neg�cio.
		 * CEP (de um colaborador do Itau) => 00010-009
		 * CPF (de um aluno de uma universidade) => alfanum�rico
		 * Em Java=> String
		 * 
		 * - num�rico: � o dado que PODE ser utilizado em uma express�o matem�tica.
		 * CEP (diante de um contexto do site dos Correios) => 00010009
		 * CPF (contexto do site da Receita Federal) => num�rico
		 * RM (contexto de uma universidade - n�mero de matricula)
		 * Em Java => int (n�meros inteiros) e double (para n�meros reais)  
 		 */
		
		/*
		 * Nome da variavel = identificador
		 * Regras
		 * - 1� n�o come�ar�s com n�meros. 1berto (n�o pode) h1berto (pode)
		 * - 2� n�o far�s uso de palavras reservadas. int (n�o pode) class (n�o pode)
		 * - 3� n�o usar�s caracteres especiais. d@t@ (n�o pode) nome cliente (n�o pode) 
		 * 
		 * Padroes
		 * - nomes significativos. Evitem: x, n1, xpto... 
		 * - come�a com letra minuscula
		 * - padr�o CamelCase
		 * dataNascimento (correto)
		 * datanascimento (errado)
		 * data_nascimento (correto)
		 * data_Nascimento (errado)
		 */
		
		String nome = JOptionPane.showInputDialog("Digite o seu nome");
		/*
		 * Tipos num�ricos s�o primitivos, para apoi�-los, usamos as classes Wrappers.
		 * int => Integer
		 * double => Double
		 * short => Short
		 * boolean => Boolean
		 */
		int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog("Digite a altura"));
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Digite o peso"));
		double imc = peso / (altura * altura);
		
		System.out.println("Nome...: " + nome);
		System.out.println("Idade..: " + idade);
		System.out.println("Altura.: " + altura);
		System.out.println("IMC....: " + imc);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
