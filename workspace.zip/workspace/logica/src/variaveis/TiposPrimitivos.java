package variaveis;

import javax.swing.JOptionPane;

public class TiposPrimitivos {

	public static void main(String[] args) {
		
		/*
		 * boolean => dado l�gico (true/false) - Boolean
		 * char => 1 caracter - Character
		 * -- para numeros inteiros ---
		 * byte => -127 +128 - Byte
		 * short => -32.??? + 32.??? - Short
		 * int => -2bilhoes + 2bilhoes - Integer
		 * long => ????lhoes   - Long
		 * -- para n�meros reais -- 
		 * float => menos exatid�o
		 * double => dobro de precis�o nas casas decimais quando comparado ao float
		 */
		
		/* criem as variaveis para:
		 * nota (semestral1)
		 * nota (semestral2)
		 * falta (m�ximo 200)
		 * disciplina (nome da mat�ria)
		 * media (calculem) 
		 */

		float semestral1 = Float.parseFloat(JOptionPane.showInputDialog("Semestral 1"));
		float semestral2 = Float.parseFloat(JOptionPane.showInputDialog("Semestral 2"));
		short faltas = Short.parseShort(JOptionPane.showInputDialog("Faltas"));
		String disciplina = JOptionPane.showInputDialog("Disciplina");
		float media = (semestral1+semestral2) /2;
		System.out.println("Disciplina: " + disciplina);
		System.out.println("Faltas: " + faltas);
		System.out.println("M�dia: " + media);
		// Cast: convers�o entre tipos compat�veis
		float semestral3 = (float) 7.45;
		int teste = (int) semestral3;
		short pequena = (short) teste;
		long maior = pequena;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
