package variaveis;

public class Itau { // criando a classe 

// o m�todo main � o start point de uma aplica��o Java
/*
 * o Java utiliza o paradigma de POO
 * o Java � uma linguagem de m�dio nivel
 * O Java possui uma arquitetura hibrida
 * 
 */	
public static void main(String[] args) {
	
	System.out.print("Ol� mundo!!!");
	
	
}// fecha o m�todo

}// fecha a classe
