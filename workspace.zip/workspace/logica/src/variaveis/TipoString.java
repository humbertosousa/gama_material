package variaveis;

public class TipoString {

	public static void main(String[] args) {
		// String => � um tipo de Refer�ncia
		// Date => � um tipo de Refer�ncia
		String email= "xpto@itau-unibanco.com.br";
		System.out.println("Original: " + email);
		System.out.println("Maiusculo: " + email.toUpperCase());
		System.out.println("Minusculo: " + email.toLowerCase());
		// length() => retorna qtde de caracteres da String
		System.out.println("Qtde Caracteres: " + email.length());
		// contains() => retorna true/false sobre a existencia ou n�o do caracter
		System.out.println("Tem arroba?" + email.contains("@"));
		// indexOf() => retorna a POSI��O do caracter ou da substring
		System.out.println("Posi��o do @: " + email.indexOf("@"));
		// substring() => retorna uma parte da string com base nas coordenadas: inicial e final
		System.out.println("Do 2� at� o 5�: " + email.substring(1,5));
		System.out.println("A partir do 3�: " + email.substring(2,email.length()));
		// exibir somente o usu�rio do email
		System.out.println("Usu�rio: " + email.substring(0,email.indexOf("@")));
		// exibir somente o servidor 
		System.out.println("Servidor: " + email.substring(email.indexOf("@")+1));
		//h u m b e r t o @ f i 
		//0 1 2 3 4 5 6 7 8 9 10
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
