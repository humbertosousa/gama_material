package variaveis;

public class Itau {
	public static void main(String[] args) {
		/*
		 * O m�todo main � o start point de uma aplica��o
		 * Todo m�todo vem seguido de parenteses
		 * 
		 */
		System.out.print("Hello World");
		

	} // fechando o m�todo main

} // fechando a classe Itau
