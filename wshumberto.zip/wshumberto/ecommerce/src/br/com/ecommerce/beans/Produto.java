package br.com.ecommerce.beans;

public class Produto {

}
