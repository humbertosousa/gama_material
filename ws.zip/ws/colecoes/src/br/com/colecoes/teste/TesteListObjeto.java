package br.com.colecoes.teste;

import java.util.ArrayList;
import java.util.List;

import br.com.colecoes.modelo.Cargo;

public class TesteListObjeto {

	public static void main(String[] args) {
		
		List<Cargo> lista = new ArrayList<Cargo>();
		
		lista.add(new Cargo("DBA", "JR", 5000));
		lista.add(new Cargo("DEV", "JR", 4000));
		lista.add(new Cargo("GERENTE DE PROJETO", "PL", 10000));
		lista.add(new Cargo("DBA", "SR", 15000));
		lista.add(new Cargo("ESTAGIARIO", "PL", 3000));
		System.out.println(lista);
		//for tradicional
		/*for(int contador=0;contador<lista.size();contador++) {
			System.out.println("Cargo: " + lista.get(contador).getNome());
			System.out.println("N�vel: " + lista.get(contador).getNivel());
			System.out.println("Salario: " + lista.get(contador).getSalario());
		}*/	
		//foreach
		double total =0;
		double totalSalarioDba=0;
		for (Cargo cargo : lista) {
			if (cargo.getNome().equals("DBA")) {
				totalSalarioDba+=cargo.getSalario();
			}
			total+=cargo.getSalario();
			System.out.println("Cargo: " + cargo.getNome());
			System.out.println("N�vel: " + cargo.getNivel());
			System.out.println("Salario: " + cargo.getSalario());
		}
		/*
		 * Retornem: 
		 * o total de salarios
		 * a m�dia de salarios
		 * o total de salarios do DBA
		 */
		System.out.println("Total Geral: " + total);
		System.out.println("M�dia Geral: " + (total/lista.size()));
		System.out.println("Total de Sal�rio DBA: " + totalSalarioDba);
		
		
		

	}

}
