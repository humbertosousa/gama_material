package br.com.colecoes.teste;

import java.util.HashMap;
import java.util.Map;

import br.com.colecoes.modelo.Cargo;

public class TesteMap {

	public static void main(String[] args) {
		/*
		 * Map manipula o generics com dois dados:
		 * - Key : chave (Set)
		 * - Value : dados / valores (List)
		 */
		Map<Integer, Cargo> lista = new HashMap<Integer, Cargo>();
		
		lista.put(1, new Cargo("DBA","JR",5000));
		lista.put(2, new Cargo("DBA","PL",10000));
		lista.put(3, new Cargo("DBA","SR",15000));
		
		System.out.println(lista);
		System.out.println("Chaves: " + lista.keySet());
		System.out.println("Valores: " + lista.values());
		
		for(Cargo cargo : lista.values()) {
			System.out.println(cargo.getNome());
			System.out.println(cargo.getSalario());
		}
		
		/*
		 * JSON => padr�o que permite a troca de dados entre diferentes
		 * plataformas e/ou linguagens
		 * Concorrente do XML
		 * 
		 */
		
		
		
		
		
		
		
		

	}

}
