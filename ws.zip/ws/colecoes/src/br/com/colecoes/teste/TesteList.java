package br.com.colecoes.teste;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class TesteList {

	public static void main(String[] args) {
		// Criar pelo pai e instanciar pelo filho
		/*
		 * Caracteristicas de List
		 * - tamanho � din�mico
		 * - dados podem ser heterogeneos
		 * - n�o precisa de recursos adicionais para gerenciar o indice
		 * - � permitido excluir uma posi��o
		 * - ordena��o � bem simples
		 * 
		 */
		List<String> lista = new ArrayList<String>(); // lista (generics)
		lista.add("DBA");
		lista.add("GERENTE DE PROJETOS");
		lista.add("DEV");
		lista.add("ESTAGIARIO");
		lista.add("DBA");
		
		System.out.println("Segundo elemento: " + lista.get(1));
		System.out.println("Todos os elementos: " + lista);
		lista.remove(0); // removendo o primeiro elemento
		System.out.println("Sem um DBA: " + lista);
		
		Collections.sort(lista); // .reverse() => Z-A
		System.out.println("Ordenada: " + lista);
		
		int qtdeDba=0;
		for (int contador=0;contador<lista.size();contador++) {
			if (lista.get(contador).equals("DBA")) {
				qtdeDba++;
			}
			System.out.println("Cargo: " + lista.get(contador));
		}
		
		System.out.println("Total de DBA�s: " + qtdeDba);
		
	
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
