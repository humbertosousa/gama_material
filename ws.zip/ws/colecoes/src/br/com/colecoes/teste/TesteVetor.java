package br.com.colecoes.teste;

import javax.swing.JOptionPane;

public class TesteVetor {
	/*
	 * Caracter�sticas do vetor:
	 * - o tamanho do vetor � est�tico
	 * - os dados s�o homogeneos (todos do mesmo tipo)
	 * - n�o � permitido excluir uma posi��o
	 * - precisa de uma vari�vel como indice
	 * - a ordena��o dos dados � trabalhosa
	 */
	public static void main(String[] args) {
	
		int fones[] = new int[3];
		int indice = 0;
		
		while (indice<3) {
			fones[indice] = Integer.parseInt(JOptionPane.showInputDialog("Telefone"));
			indice++;
		}		
		
		for (int contador=0;contador<3;contador++) {
			System.out.println("Elemento do vetor: " + fones[contador]);
		}
		
		
		
		
		
		
		
		

	}

}
