package repeticao;

import javax.swing.JOptionPane;

public class ExemploDo2 {

	public static void main(String[] args) {
		/*
		 * Jogador1 vai digitar um n�mero inteiro
		 * Jogador2 vai ter que advinhar
		 * Quando o jogador2 advinhar o n�mero voc� vai mostrar uma mensagem de Parab�ns 
		 * 
		 * Missao 2:
		 * Fornecer dicas para o jogador 2, informando se ele est� chutando
		 * alto ou baixo.
		 * 
		 * Missao 3:
		 * Vao acrescentar na mensagem de parab�ns quantas tentativas
		 * o jogador 2 utilizou at� advinhar. 
		 * (Dica: vai ter que usar uma vari�vel pra contar)
		 * 17h20 Corre��o
		 */
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("N�mero"));
		int chute = 0;
		int contador=0;
		do {
			chute = Integer.parseInt(JOptionPane.showInputDialog("Chute..."));
			contador=contador+1;
			//contador++;
			//contador+=1;
			if (chute>numero) {
				System.out.println("Voc� est� chutando alto");
			}else if(chute<numero) {
				System.out.println("Voc� est� chutando baixo");
			}
			
		}while(numero!=chute);
		
		System.out.println("Parab�ns voc� acertou com " + contador + " tentativa(s).");
		
		
		
		
	}
	
}
