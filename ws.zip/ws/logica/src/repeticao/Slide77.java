package repeticao;

import javax.swing.JOptionPane;

public class Slide77 {

	public static void main(String[] args) {

		String nome="";
		short idade=0;
		short qtdeMaiorIdade=0;
		short qtdePessoas=0;
		short totalIdades=0;
		short idadeMaisExperiente=0;
		String nomeMaisExperiente="";
		short idadeMaisJovem=0;
		String nomeMaisJovem="";
		do {
			nome=JOptionPane.showInputDialog("Nome").toUpperCase();
			idade=Short.parseShort(JOptionPane.showInputDialog("Idade"));
			if (idade<idadeMaisJovem || qtdePessoas==0) {
				idadeMaisJovem=idade;
				nomeMaisJovem=nome;
			} 
			if (idade>idadeMaisExperiente) {
				idadeMaisExperiente = idade;
				nomeMaisExperiente=nome;
			}
			qtdePessoas++;
			totalIdades = (short) (totalIdades+idade);
			if (idade>17) {
				qtdeMaiorIdade++;
			}
		}while(JOptionPane.showConfirmDialog
			  (null, "Continuar?","Titulo", JOptionPane.YES_NO_OPTION)==0);
		
		System.out.println("Maiores de idade.: " + qtdeMaiorIdade);
		System.out.println("Total de Pessoas.: " + qtdePessoas);
		System.out.println("Soma das Idades..: " + totalIdades);
		System.out.println("M�dia Idade......: " + (totalIdades/qtdePessoas));
		System.out.println("Idade Mais Exp...: " + idadeMaisExperiente);
		System.out.println("Nome Mais Exp....: " + nomeMaisExperiente);
		System.out.println("Idade Mais Jov...: " + idadeMaisJovem);
		System.out.println("Nome Mais Jov....: " + nomeMaisJovem);
		
		
		
		
		

	}

}
