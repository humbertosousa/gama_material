package repeticao;

import javax.swing.JOptionPane;

public class ExemploDo {

	public static void main(String[] args) {

		do {
			float valor1 = Float.parseFloat(JOptionPane.showInputDialog("Valor 1"));
			float valor2 = Float.parseFloat(JOptionPane.showInputDialog("Valor 2"));
			char operador = JOptionPane.showInputDialog("Operador").charAt(0);
			if (operador=='+') {
				JOptionPane.showMessageDialog(null, "Resultado: " + (valor1+valor2));
			}else if (operador=='-') {
				JOptionPane.showMessageDialog(null, "Resultado: " + (valor1-valor2));
			}else if (operador=='*') {
				JOptionPane.showMessageDialog(null, "Resultado: " + (valor1*valor2));
			}else if (operador=='/') {
				if (valor2!=0) {
					JOptionPane.showMessageDialog(null, "Resultado: " + (valor1/valor2));
				}
			}else {
				JOptionPane.showMessageDialog(null, "Operador inv�lido");
			}
		}while(JOptionPane.showConfirmDialog
				(null, "Continuar?", "Pergunta", JOptionPane.YES_NO_OPTION)==0);



















	}


}
