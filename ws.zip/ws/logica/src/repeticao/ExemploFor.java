package repeticao;

import javax.swing.JOptionPane;

public class ExemploFor {

	public static void main(String[] args) {
		
		/*
		 * Sintaxe, exige tr�s par�metros:
		 * - a vari�vel que ir� controlar o la�o e o valor inicial
		 * - a condi��o para parar o la�o
		 * - incremento (de quanto em quanto a vari�vel vai contar)
		 */
		// ??? x 1 = ???
		// ??? x 2 = ???
		// ....x 10 = ???
		
		int tabuada = Integer.parseInt(JOptionPane.showInputDialog("Digite a tabuada: "));
		for (int contador=1;contador<11;contador+=1) {
			System.out.println(tabuada + " x " + contador + " = " + (tabuada*contador));

		}
		

		
		
		
		
		
	}
	
	
}
