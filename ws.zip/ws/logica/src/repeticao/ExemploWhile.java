package repeticao;

import javax.swing.JOptionPane;

public class ExemploWhile {

	
	public static void main(String[] args) {
		
		String email = JOptionPane.showInputDialog("Email").toLowerCase();
		while (email.contains("@")==false) {
			email = JOptionPane.showInputDialog("Digite o email novamente").toLowerCase();
		}
		System.out.println("E-mail: " + email);
		/*
		 * Validem o nome de uma pessoa
		 * - N�o pode ter menos que 3 caracteres
		 * - N�o pode ter mais que 15 caracteres
		 */
		
		String nome = JOptionPane.showInputDialog("Nome").toUpperCase();
		while (nome.length()<3 || nome.length()>15) {
			nome = JOptionPane.showInputDialog("Nome").toUpperCase();
		}
		System.out.println("Nome: " + nome);
		
		String data = "13/04/2021";
		/*
		 * Validar o dia (que deve estar entre 1 e 31)
		 * Validar o mes (que deve estar entre 1 e 12)
		 * Depois que validar a exibir a data j� validada.
		 */
		int dia = Integer.parseInt(data.substring(0,2));
		int mes = Integer.parseInt(data.substring(3,5));
		int ano = Integer.parseInt(data.substring(6));
		
		while (dia<1 || dia >31) {
			dia = Integer.parseInt(JOptionPane.showInputDialog("Dia"));
		}
		
		while (mes<1 || mes>12) {
			mes = Integer.parseInt(JOptionPane.showInputDialog("M�s"));
		}
		
		System.out.println("Data validada: " + dia + "/" + mes + "/" + ano);
		
		
		
		
		
	}
	
	
}
