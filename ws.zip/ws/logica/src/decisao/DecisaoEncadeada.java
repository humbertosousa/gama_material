package decisao;

import javax.swing.JOptionPane;

public class DecisaoEncadeada {

	public static void main(String[] args) {
		/*
		 * Capturar a qtde de faltas
		 * Para que o aluno esteja aprovado ou de exame a quantidade de faltas
		 * deve ser menor que 20
		 */
		String disciplina = JOptionPane.showInputDialog("Disciplina").toUpperCase();
		short faltas = Short.parseShort(JOptionPane.showInputDialog("Faltas"));
		if (faltas<20) {
			float nota1 = Float.parseFloat(JOptionPane.showInputDialog("Nota 1"));
			float nota2 = Float.parseFloat(JOptionPane.showInputDialog("Nota 2"));
			float media = (nota1+nota2)/2;
			if (media>=6) {
				JOptionPane.showMessageDialog(null, "Parab�ns!!! Voc� foi aprovado!");
			}else if (media<4) {
				System.out.println("Infelizmente voc� foi reprovado!");
			}else {
				System.out.println("Voc� ainda tem uma chance no exame");
			}
			System.out.println("Sua m�dia na disciplina " + disciplina + " foi " + media);
		}else {
			System.out.println("Reprovou por faltas!!!!!");
		}













	} // fecha o m�todo main()


} // fecha a classe
