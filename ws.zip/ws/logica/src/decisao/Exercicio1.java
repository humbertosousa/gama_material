package decisao;

import javax.swing.JOptionPane;

public class Exercicio1 {

	public static void main(String[] args) {
		/*
		 * Solicite:
		 * nome de um produto, qtde a ser comprada e o valor unitario
		 * Se a qtde a ser comprada for maior que 50, o valor unit�rio
		 * do produto ter� um desconto de 10%
		 * Se a qtde a ser comprada estiver entre 40 e 50, o desconto
		 * ser� de 8%
		 * Se a qtde a ser comprada estiver entre 20 e 40, o desconto ser�
		 * de 5%
		 * E ent�o exiba no final o nome do produto e valor total da compra.
		 * Somente exiba o valor total da compra se o valor unitario e a qtde
		 * forem maiores que 0.
		 */
		String produto = JOptionPane.showInputDialog("Produto: ").toUpperCase();
		short qtde = Short.parseShort(JOptionPane.showInputDialog("Qtde"));
		float valorUnitario = Float.parseFloat(JOptionPane.showInputDialog("Unit�rio"));
		float desconto = 0;
		if (valorUnitario>0 && qtde>0) {
			
			if (qtde>50) {
				desconto = (float) 0.1;
			}else if (qtde>=40 && qtde<=50) {
				desconto = (float) 0.08;
			}else if (qtde>=20 && qtde<40){
				desconto = (float) 0.05;
			}
			float total = (valorUnitario - valorUnitario * desconto) * qtde; 
			System.out.println("Total do Produto: " + produto + " eh: " + total);
		}else {
			System.out.println("Existem valores iguais a zero.");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
}
