package decisao;

import javax.swing.JOptionPane;

public class DecisaoSimples2 {

	public static void main(String[] args) {
		
		/*
		 * Pedir para o usu�rio:
		 * - nome
		 * - idade
		 * Se a idade for igual a 16, ou igual a 17 ou maior que 70, deve exibir 
		 * a mensagem "Seu voto � facultativo"
		 * Se a idade estiver entre 18 (incluso) e 70 (incluso), deve exibir
		 * a mensagem "Seu voto � obrigatorio"
		 * Se a idade for menor que 16 deve exibir "Voc� n�o pode votar"
		 * 
		 */
		
		String nome = JOptionPane.showInputDialog("Digite o nome").toUpperCase();
		short  idade = Short.parseShort(JOptionPane.showInputDialog("Idade"));
		
		if (idade<16) {
			System.out.println(nome + " voc� n�o pode votar.");
		}
		
		if (idade>=18 && idade<=70) {
			System.out.println(nome + " seu voto � obrigat�rio.");
		}
		
		if (idade==16 || idade==17 || idade>70) {
			System.out.println(nome + " seu voto � facultativo.");
		}
		
		
		
		
		
		
	} // fecha o m�todo main()
	
	
} // fecha a classe
