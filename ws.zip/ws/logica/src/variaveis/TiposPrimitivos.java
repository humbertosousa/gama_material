package variaveis;

import javax.swing.JOptionPane;

public class TiposPrimitivos {

	/*
	 * Tipos Primitivos:
	 * boolean=> l�gico (true/false)
	 * char   => armazena 1 caracter (usa-se o ap�strofo)
	 * byte   => n� inteiro => -128/+127 
	 * short  => n� inteiro => -32 mil/+32 mil
	 * int    => n� inteiro => -2trilhoes/+2trilhoes (padr�o do Java)
	 * long   => n� inteiro => -9quintilhoes/+9quintilhoes
	 * float  => n� real => possui menos precis�o nas casas decimais (5 casas)
	 * double => n� real => possui precis�o m�xima nas casas decimais (padr�o do Java)
	 * 
	 */
	
	public static void main(String[] args) {
		
		float salarioBruto = Float.parseFloat(JOptionPane.showInputDialog("Salario"));
		byte filhos = Byte.parseByte(JOptionPane.showInputDialog("Filhos"));
		float familia = Float.parseFloat(JOptionPane.showInputDialog("Familia"));
		float fgts = salarioBruto * (float) 0.08; //casting � um ajuste de tamanho
		float salarioLiquido = salarioBruto + familia * filhos - fgts;
		System.out.println("Salario Liquido: " + salarioLiquido);
		
		
		
		
		
		/*
		 * Pedir os seguintes dados:
		 * salario bruto
		 * quantidade de filhos
		 * salario familia
		 * fgts (8% sobre o salario bruto)
		 * Exibir o salario liquido 
		 * (salario bruto mais o salario familia multiplicado pela 
		 * quantidade de filhos) subtraindo o fgts
		 */
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
