package variaveis;

import javax.swing.JOptionPane;

public class Tipos {
	// o m�todo main() � o start point da aplica��o Java
	
	/*
	 * Padronizacao
	 * - Toda classe comeca com letra maiuscula
	 * - Todo m�todo vem seguido de parenteses e comeca com
	 * letra minuscula
	 */
	
	/*
	 * Dois Tipos de Dados:
	 * 1�) Alfanum�rico: � o dado que n�o ser� envolvido em opera��es
	 * matem�ticas.
	 * CEP (no contexto de RH do bco Itau - colaboradores)=> ?0010-009
	 * Em Javan�s:
	 * String => � um dado do tipo Refer�ncia (faz referencia para
	 * uma classe) 
	 * 
	 * 2�) Num�rico: � o dado que PODE ser utilizado em opera��es
	 * matem�ticas.
	 * CEP (no contexto da app dos Correios) => ?0010009 => 1
	 * Em Javan�s (dados primitivos):
	 * - int => para n�meros sem casas decimais
	 * - double => para n�mero com casas decimais
	 * 
	 * Sintaxe para criar as vari�veis
	 * <tipo do dado> <nome da variavel> = <valor inicial>;
	 */
	public static void main(String[] args) {
	
		String nome = JOptionPane.showInputDialog("Nome: ");
		int idade = 
				Integer.parseInt(JOptionPane.showInputDialog("Digite a idade"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog("Altura"));
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Peso"));
		double imc = peso / (altura * altura);
		/*
		 * Classes Wrappers
		 * S�o classes que apoiam os tipos Primitivos (int, double)
		 * int => Integer
		 * double => Double
		 * boolean => Boolean
		 * 
		 * Parse: � uma convers�o entre tipos de dados incompativeis
		 */
		System.out.println("Nome..: " + nome);
		System.out.println("Idade.: " + idade + " anos.");
		System.out.println("Altura: " + altura + " metros.");
		System.out.println("IMC...: " + imc);
		
		
		
	
	} // fecha o m�todo main()
	
} // fecha a classe Tipos


