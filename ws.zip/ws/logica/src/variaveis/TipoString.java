package variaveis;

public class TipoString {

	/*
	 * Identificadores (nomes das "coisas" - variaveis/metodos/classes/projetos)
	 * 
	 * - Padr�o (boas pr�ticas)
	 * 
	 * * Utilize o padr�o CamelCase.
	 * TipoString = dataDeNascimento = data_de_nascimento
	 * 
	 * * para nomenclatura, utilizamos o padr�o UML
	 * - Classes => come�am com letra maiuscula
	 * - variaveis => come�am com letra minuscula
	 * - m�todos => come�am com letra minuscula e vem seguido de parenteses
	 * 	 * xpto => � uma vari�vel
	 * Xpto => � uma classe
	 * xpto() => � um m�todo
	 * 
	 * * usem nomes significativos
	 * 
	 * - Regra
	 * 1�) n�o come�aras com n�meros. 1berto (errado) - h1berto (certo)
	 * 2�) n�o utilizar�s palavras reservadas. public (errado) - int (errado)
	 * 3�) n�o far�s uso de caracteres especiais. n@me (errado) - cli#nt# (errado)
	 */

	public static void main(String[] args) {

		String email = "huMberTo@fiaP.cOm.Br";
		System.out.println("Original: " + email);
		System.out.println("Minusculos: " + email.toLowerCase());
		System.out.println("Maiusculos: " + email.toUpperCase());
		System.out.println("Qtde Caracteres: " + email.length());
		System.out.println("Tem arroba? " + email.contains("@"));
		System.out.println("Posi��o do @: " + email.indexOf("@"));
		System.out.println("Do 3� ao 6�: " + email.substring(2, 6).toLowerCase());
		System.out.println("Primeira metade: " + email.substring(0, email.length()/2));
		System.out.println("Segunda metade: " + email.substring(email.length()/2));

		if (email.contains("@")==true) {
			System.out.println("Usu�rio: " + email.substring(0, email.indexOf("@")).toLowerCase()); // tudo que estiver antes do @
			System.out.println("Servidor: " + email.substring(email.indexOf("@")+1).toLowerCase()); // tudo que estiver depois do @
		}

		// ???.contrafatos()
		// h u m b e r t o @ f ...
		// j o f e r s o n @
		// 0 1 2 3 4 5 6 7 8 9 ...


		// ?????.yyyy() => m�todo
		// yyyy() => fun��o
		// len() = print() => func�es do Python
		// email.upper() => m�todos do Python

















	}


}
