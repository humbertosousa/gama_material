package br.com.xpto.interfaces;

import br.com.xpto.modelo.Cliente;

public interface PadraoCliente {

	public String getResumo();
	public boolean gravar(Cliente objeto);
	public Cliente consultar(int id);
	public boolean excluir(int id);
	public Cliente alterar(Cliente objeto);
	
	
	
}
