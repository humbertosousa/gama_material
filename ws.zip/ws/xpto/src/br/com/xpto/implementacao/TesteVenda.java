package br.com.xpto.implementacao;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Pagamento;
import br.com.xpto.modelo.Produto;
import br.com.xpto.modelo.Venda;

public class TesteVenda {

	public static void main(String[] args) {

		Venda venda = new Venda();
		venda.setData("26/04/2021");
		venda.setNotaFiscal(123);
		List<Produto> listapro = new ArrayList<Produto>();
		do {
			listapro.add(new Produto(
					Integer.parseInt(JOptionPane.showInputDialog("Id")),
					JOptionPane.showInputDialog("Descricao").toUpperCase(),
					Integer.parseInt(JOptionPane.showInputDialog("Qtde")),
					Double.parseDouble(JOptionPane.showInputDialog("Valor Venda")),
					0
					));
		}while(JOptionPane.showConfirmDialog(null, "?","Tit", JOptionPane.YES_NO_OPTION)==0);
		venda.setProdutos(listapro);
		
		List<Pagamento> listapag = new ArrayList<Pagamento>();
		do {
			listapag.add(new Pagamento(
						Integer.parseInt(JOptionPane.showInputDialog("Numero")),
						Double.parseDouble(JOptionPane.showInputDialog("Valor")),
						JOptionPane.showInputDialog("Forma").toUpperCase()
					));
		}while(JOptionPane.showConfirmDialog(null, "?","Tit", JOptionPane.YES_NO_OPTION)==0);
		venda.setPagamentos(listapag);
		
		
		double totalQtde=0;
		for(Produto objeto : venda.getProdutos()) {
			totalQtde+=objeto.getQtde();
		}
		double totalPagamentos=0;
		for (Pagamento objeto : venda.getPagamentos()) {
			totalPagamentos+=objeto.getValor();
		}
		
		System.out.println("Total de Quantidades: " + totalQtde);
		System.out.println("Total de Pagamentos: " + totalPagamentos);
		venda.setTotal(totalPagamentos);
		
		System.out.println("Venda: " + venda.toString());
	}

}
