package br.com.xpto.implementacao;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Cliente;

public class TesteCliente {

	public static void main(String[] args) {
		
		//1� passo - instanciar o objeto
		Cliente objeto = new Cliente( ); //n�o esque�am de importar
		
		//2� passo - preencher o objeto (inputs - setters)
		objeto.setEmail(JOptionPane.showInputDialog("Email").toLowerCase());
		objeto.setFone(JOptionPane.showInputDialog("Fone"));
		objeto.setId(Integer.parseInt(JOptionPane.showInputDialog("ID")));
		objeto.setNome(JOptionPane.showInputDialog("Nome").toUpperCase());
		
		// 3� passo - testar as sa�das (outputs - getters)
		System.out.println("Email: " + objeto.getEmail());
		System.out.println("Nome: " + objeto.getNome());
		System.out.println("Fone: " + objeto.getFone());
		System.out.println("ID: " + objeto.getId());
		System.out.println("Tudo: " + objeto.toString());
		
		
		
		
		
		
		
		
	}
	
}
