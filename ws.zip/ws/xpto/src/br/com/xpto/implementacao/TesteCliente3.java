package br.com.xpto.implementacao;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Cliente;
import br.com.xpto.modelo.Endereco;

public class TesteCliente3 {

	public static void main(String[] args) {
		

		Cliente objeto = new Cliente(
				Integer.parseInt(JOptionPane.showInputDialog("ID")),
				JOptionPane.showInputDialog("Nome"),
				JOptionPane.showInputDialog("Email"),
				JOptionPane.showInputDialog("Fone"),
				new Endereco(
						"Log",
						"Num",
						"Comp",
						"Bai",
						"Cid",
						"SP",
						"00000-000"
						)
				);
		
		System.out.println(objeto.getEndereco().getBairro());
		
		
		
		
		
		
		
		
		
		

	}

}
