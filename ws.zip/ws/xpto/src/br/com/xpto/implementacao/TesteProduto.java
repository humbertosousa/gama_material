package br.com.xpto.implementacao;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Produto;

public class TesteProduto {

	public static void main(String[] args) {

		
		Produto objeto = new Produto();
			
		System.out.println(objeto.getId());
		System.out.println(objeto.getDescricao());
		objeto.setId(5);
		
		objeto.setAll(
				Integer.parseInt(JOptionPane.showInputDialog("ID")), 
				JOptionPane.showInputDialog("Descricao").toUpperCase(), 
				Integer.parseInt(JOptionPane.showInputDialog("Qtde")), 
				Double.parseDouble(JOptionPane.showInputDialog("Venda")), 
				Double.parseDouble(JOptionPane.showInputDialog("Compra")));
		
		objeto.setValores(4);
		System.out.println(objeto.getTotalVenda());
		System.out.println("Valor com Desconto: " + objeto.getDesconto());
		System.out.println("Valor com 15% de desconto: " + objeto.getDesconto(15));
		
		System.out.println(objeto.toString());
		
		
		
		
		
		
		

	}

}
