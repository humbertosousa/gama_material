package br.com.xpto.implementacao;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Cliente;
import br.com.xpto.modelo.Endereco;
import br.com.xpto.modelo.PessoaFisica;
import br.com.xpto.modelo.PessoaJuridica;

public class TesteClienteHeranca {

	public static void main(String[] args) {

		//Criando pelo pai e instanciando pela filha
		Cliente cliente = new Cliente();
		
		if (JOptionPane.showConfirmDialog(null, "PF?", "Titulo", JOptionPane.YES_NO_OPTION)==0) {	
			cliente = new PessoaFisica(
					1,
					"1BERTO",
					"humberto@fiap.com.br",
					"996151212",
					new Endereco(),
					"123456456-11",
					"111234467"
					);	
		}else {
			cliente = new PessoaJuridica(
					2,
					"CHURROS E CIA",
					"CHURROS@CHURROS.COM.BR",
					"1234-9874",
					new Endereco(),
					"11123456000105",
					123,
					"Sra. Regina"
					);
		}
		
		System.out.println(cliente.toString());
		System.out.println("Resumo: " + cliente.getResumo());
		
		
		
	} // fecha o main

} // fecha a classe
