package br.com.xpto.implementacao;

import javax.swing.JOptionPane;

import br.com.xpto.modelo.Cliente;
import br.com.xpto.modelo.Endereco;

public class TesteCliente2 {

	public static void main(String[] args) {
		//1� Passo: instanciar o objeto
		Cliente objeto = new Cliente();
		Endereco endereco = new Endereco();
		
		//2� Passo: preencher o objeto (input)
		endereco.setAll(
				"Av Itaquera", 
				"123", 
				"", 
				"Itaquera", 
				"S�o Paulo", 
				"SP", 
				"12345-000");
		
		objeto.setAll(
				Integer.parseInt(JOptionPane.showInputDialog("ID")), 
				JOptionPane.showInputDialog("Nome"), 
				JOptionPane.showInputDialog("Email"), 
				JOptionPane.showInputDialog("Fone"),
				endereco);
		
		//3� Passo: exibir os dados do objeto (output)
		System.out.println(objeto.getResume());
		System.out.println("Usu�rio: " + objeto.getUsuario());
		System.out.println(objeto.toString());
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}
