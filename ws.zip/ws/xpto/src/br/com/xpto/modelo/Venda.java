package br.com.xpto.modelo;

import java.util.List;

public class Venda {

	private int notaFiscal;
	private String data;
	private double total;
	private List<Produto> produtos;
	private List<Pagamento> pagamentos;
	public int getNotaFiscal() {
		return notaFiscal;
	}
	public void setNotaFiscal(int notaFiscal) {
		this.notaFiscal = notaFiscal;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public List<Produto> getProdutos() {
		return produtos;
	}
	public void setProdutos(List<Produto> produtos) {
		this.produtos = produtos;
	}
	public List<Pagamento> getPagamentos() {
		return pagamentos;
	}
	public void setPagamentos(List<Pagamento> pagamentos) {
		this.pagamentos = pagamentos;
	}
	public Venda(int notaFiscal, String data, double total, List<Produto> produtos, List<Pagamento> pagamentos) {
		super();
		this.notaFiscal = notaFiscal;
		this.data = data;
		this.total = total;
		this.produtos = produtos;
		this.pagamentos = pagamentos;
	}
	public Venda() {
		super();
	}
	@Override
	public String toString() {
		return "Venda [notaFiscal=" + notaFiscal + ", data=" + data + ", total=" + total + ", produtos=" + produtos
				+ ", pagamentos=" + pagamentos + "]";
	}
	public void setAll(int notaFiscal, String data, double total, List<Produto> produtos, List<Pagamento> pagamentos) {
		this.notaFiscal = notaFiscal;
		this.data = data;
		this.total = total;
		this.produtos = produtos;
		this.pagamentos = pagamentos;
	}
	
	
	
}
