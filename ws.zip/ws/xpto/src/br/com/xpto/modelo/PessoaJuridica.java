package br.com.xpto.modelo;

import br.com.xpto.interfaces.PadraoCliente;

public class PessoaJuridica  extends Cliente implements PadraoCliente{

	private String cnpj;
	private int cnae;
	private String contato;
	
	public void setAll(int id, String nome, String email, String fone, Endereco endereco, String cnpj, int cnae,
			String contato) {
		super.setAll(id, nome, email, fone, endereco);
		this.cnpj = cnpj;
		this.cnae = cnae;
		this.contato = contato;
	}


	@Override
	public String toString() {
		return "PessoaJuridica [cnpj=" + cnpj + ", cnae=" + cnae + ", contato=" + contato + ", toString()="
				+ super.toString() + "]";
	}
	
	
	public PessoaJuridica(int id, String nome, String email, String fone, Endereco endereco, String cnpj, int cnae,
			String contato) {
		super(id, nome, email, fone, endereco);
		this.cnpj = cnpj;
		this.cnae = cnae;
		this.contato = contato;
	}
	public PessoaJuridica() {
		super();
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public int getCnae() {
		return cnae;
	}
	public void setCnae(int cnae) {
		this.cnae = cnae;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}


	@Override
	public String getResumo() {
		return cnpj + "\n" + super.getNome();
	}


	@Override
	public boolean gravar(Cliente objeto) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Cliente consultar(int id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean excluir(int id) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Cliente alterar(Cliente objeto) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
}
