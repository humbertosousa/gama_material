package br.com.xpto.modelo;

public class Pagamento {
	
	private int numero;
	private double valor;
	private String forma;
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getForma() {
		return forma;
	}
	public void setForma(String forma) {
		this.forma = forma;
	}
	public Pagamento(int numero, double valor, String forma) {
		super();
		this.numero = numero;
		this.valor = valor;
		this.forma = forma;
	}
	public Pagamento() {
		super();
	}
	@Override
	public String toString() {
		return "Pagamento [numero=" + numero + ", valor=" + valor + ", forma=" + forma + "]";
	}
	public void setAll(int numero, double valor, String forma) {
		this.numero = numero;
		this.valor = valor;
		this.forma = forma;
	}
	
	
}
