package br.com.xpto.modelo;

import br.com.xpto.interfaces.PadraoCliente;

/*
 * Design Pattern (OO)
 * DTO (Data Transfer Object) => � um pattern que indica as melhores pr�ticas para 
 * a programa��o de um classe que est� representada no diagrama de classes.
 * Sugest�es:
 * 1� TODOS os atributos devem ser privados
 * 2� Cada atributo deve possuir INDIVIDUALMENTE um m�todo setter e outro m�todo getter
 * 3� Toda classe Beans(modelo) deve possuir no MINIMO dois construtores: 
 * - um vazio (sem nenhum par�metro)
 * - um completo/cheio (com todos os par�metros para os atributos) 
 */
public class Cliente implements PadraoCliente{
	private int id;
	private String nome;
	private String email;
	private String fone;
	private Endereco endereco;
	
	// getters e setters + construtor cheio + construtor vazio + toString + setAll (construtor cheio)
	
	
	public void setAll(int id, String nome, String email, String fone, Endereco endereco) {
		this.id = id;
		this.nome = nome;
		this.email = email;
		this.fone = fone;
		this.endereco = endereco;
	}

	@Override
	public String toString() {
		return "Cliente [id=" + id + ", nome=" + nome + ", email=" + email + ", fone=" + fone + ", endereco=" + endereco
				+ "]";
	}



	public Cliente(int id, String nome) {
		super();
		this.id = id;
		this.nome = nome;
	}

	public Cliente() {
		super();
	}

	public Cliente(int id, String nome, String email, String fone, Endereco endereco) {
		super();
		this.id = id;
		this.nome = nome;
		this.email = email;
		this.fone = fone;
		this.endereco = endereco;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public String getUsuario() {
		if (email.contains("@")) {
			return email.substring(0, email.indexOf("@"));
		}
		return "Email inv�lido";
	}
	
	public String getResume() {
		return "Nome: " + nome + " - Email: " + email;
	}

	@Override
	public String getResumo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean gravar(Cliente objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cliente consultar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean excluir(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cliente alterar(Cliente objeto) {
		// TODO Auto-generated method stub
		return null;
	}



	
} // fecha a classe
