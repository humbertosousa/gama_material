package br.com.xpto.modelo;

public class Produto {

	private int id;
	private String descricao;
	private int qtde;
	private double valorVenda;
	private double valorCompra;
	
	public Produto() {
		super();
	}

	public Produto(int id, String descricao, int qtde, double valorVenda, double valorCompra) {
		super();
		this.id = id;
		this.descricao = descricao;
		this.qtde = qtde;
		this.valorVenda = valorVenda;
		this.valorCompra = valorCompra;
	}

	public void setAll(int id, String descricao, int qtde, double valorVenda, double valorCompra) {
		this.id=id;
		this.descricao=descricao;
		this.qtde=qtde;
		this.valorVenda=valorVenda;
		this.valorCompra=valorCompra;
	}
	
	public double getDesconto(double porcentagem) {
		return valorVenda - valorVenda * (porcentagem/100);
	}
	
	public double getTotalVenda() {
		return qtde * valorVenda;
	}
	
	public void setValores(double valor) {
		valorVenda+=valor;
		valorCompra+=valor;
	}
	
	public double getDesconto() {
		return valorVenda * 0.9;
	}
	
	@Override
	public String toString() {
		return "Produto [id=" + id + ", descricao=" + descricao + ", qtde=" + qtde + ", valorVenda=" + valorVenda
				+ ", valorCompra=" + valorCompra + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getQtde() {
		return qtde;
	}
	public void setQtde(int qtde) {
		this.qtde = qtde;
	}
	public double getValorVenda() {
		return valorVenda;
	}
	public void setValorVenda(double valorVenda) {
		this.valorVenda = valorVenda;
	}
	public double getValorCompra() {
		return valorCompra;
	}
	public void setValorCompra(double valorCompra) {
		this.valorCompra = valorCompra;
	}
	
	
	
	
	
}
