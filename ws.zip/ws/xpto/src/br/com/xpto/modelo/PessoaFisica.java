package br.com.xpto.modelo;

import br.com.xpto.interfaces.PadraoCliente;

public class PessoaFisica extends Cliente implements PadraoCliente{

	private String cpf;
	private String rg;
	
	public void setAll(int id, String nome, String email, String fone, Endereco endereco, String cpf, String rg) {
		super.setAll(id, nome, email, fone, endereco);
		this.cpf = cpf;
		this.rg = rg;
	}
	
	@Override
	public String toString() {
		return "PessoaFisica [cpf=" + cpf + ", rg=" + rg + ", toString()=" + super.toString() + "]";
	}
	public PessoaFisica() {
		super();
	}
	public PessoaFisica(int id, String nome, String email, String fone, Endereco endereco, String cpf, String rg) {
		super(id, nome, email, fone, endereco);
		this.cpf = cpf;
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}

	@Override
	public String getResumo() {
		return cpf + "\n" + super.getNome();
	}

	@Override
	public boolean gravar(Cliente objeto) {

		return false;
	}

	@Override
	public Cliente consultar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean excluir(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cliente alterar(Cliente objeto) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}
