package br.com.projetofinal.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import br.com.projetofinal.modelo.Usuario;

public interface UsuarioDAO extends CrudRepository<Usuario, Integer>{

	/*
	 * DAO (Data Access Object) é um pattern que sugere que 
	 * todo comando DML (insert, delete, update e select),
	 * deve ser isolado em uma camada (pacote => dao), os comandos DML´s são chamados
	 * na programação de CRUD (Create, Read, Update e Delete)
	 */
	/*
	 * Métodos padrões que o Spring cria pra VOCÊ:
	 * save(objeto): este é o método que grava E atualiza os dados da tabela
	 * findAll(): pesquisa todos os elementos da tabela
	 * findById(int pk): pesquisa um elemento na tabela por meio da chave primária
	 * deleteAll(): apaga tudo da tabela
	 * deleteById(int pk): apaga um elemento da tabela por meio da chave primária
	 */
	
	public List<Usuario> findByNome(String nome);
	public Usuario findByEmailAndSenha(String email, String senha);
	
	
	
}
