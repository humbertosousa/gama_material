package br.com.excecoes.teste;

public class TesteExcecao {

	public static void main(String[] args) {
		try {
			int numero = Integer.parseInt("7");
			System.out.println("Valor:" + numero);
			
			String palavra="";
			System.out.println("Qtde letras: " + palavra.length());
			
			int numeros[] = new int[2];
			numeros[0] = 100;
			numeros[1] = 50;
			numeros[2] = 108;
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Vetor estourou");
		}catch(NullPointerException e) {
			System.out.println("Objeto nulo");
		}catch(NumberFormatException e) {
			System.out.println("Formato de n�mero inv�lido");
		}catch(Exception churros) {
			System.out.println("Deu ruim");
			//churros.printStackTrace();
		}finally {
			System.out.println("Tenha um bom dia");
		}
		
		
		
		
		
		
		
		
		
		
		

	}

}
