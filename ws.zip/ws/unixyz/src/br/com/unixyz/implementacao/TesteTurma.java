package br.com.unixyz.implementacao;

import br.com.unixyz.beans.Aluno;
import br.com.unixyz.beans.Curso;
import br.com.unixyz.beans.Endereco;
import br.com.unixyz.beans.Professor;
import br.com.unixyz.beans.Turma;

public class TesteTurma {

	public static void main(String[] args) {
		
		Turma turma = new Turma(
				"ADS",
				"Remota",
				new Curso(
						"Analise e Dev",
						10000,
						"Extens�o",
						6
						),
				new Aluno(
						12345,
						"Aluno Xpto",
						"xpto@xpto.com.br",
						new Endereco(
								"rua x",
								"1",
								"nada",
								"Liberdade",
								"S�o Paulo",
								"SP",
								"12345-123"
								)
						),
				new Professor(
						5,
						"Professor Pardal",
						"Ms",
						"01/01/2000"
						)
				);
		
		System.out.println("Sigla: " + turma.getSigla());
		System.out.println("Nome professor: " + turma.getProfessor().getNome());
		System.out.println("Nome aluno: " + turma.getAluno().getNome());
		System.out.println("Bairro aluno: " + turma.getAluno().getEndereco().getBairro());
		System.out.println("Nome curso: " + turma.getCurso().getNome());
		System.out.println("Tudo: " + turma.toString());
		
		
		

	}

}
