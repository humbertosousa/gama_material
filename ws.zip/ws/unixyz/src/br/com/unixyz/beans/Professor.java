package br.com.unixyz.beans;
/*
 * DTO:
 * - todos os atributos devem ser privados
 * - cada atributo deve possuir o seu getter e setter 
 * (Menu: Source / Generate Getters and Setters)
 * - dois construtores, sendo um cheio e outro vazio, no MINIMO
 * (Menu: Source / Generate Constructor using fields)
 * 
 * Opcional (dica)
 * -  criar o toString()
 * (Menu: Source / Generate toString()
 * - criar o setAll() 
 * =>geramos um construtor cheio
 * (Menu: Source / Generate Constructor using fields)
 * => modificamos o nome para setAll (acrescentando o void)
 * => retiramos o super()
 */
public class Professor {

	private int id;
	private String nome;
	private String formacao;
	private String contratacao;
	
	public void setAll(int id, String nome, String formacao, String contratacao) {
		this.id = id;
		this.nome = nome;
		this.formacao = formacao;
		this.contratacao = contratacao;
	}
	@Override
	public String toString() {
		return "Professor [id=" + id + ", nome=" + nome + ", formacao=" + formacao + ", contratacao=" + contratacao
				+ "]";
	}
	public Professor() {
		super();
	}
	public Professor(int id, String nome, String formacao, String contratacao) {
		super();
		this.id = id;
		this.nome = nome;
		this.formacao = formacao;
		this.contratacao = contratacao;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getFormacao() {
		return formacao;
	}
	public void setFormacao(String formacao) {
		this.formacao = formacao;
	}
	public String getContratacao() {
		return contratacao;
	}
	public void setContratacao(String contratacao) {
		this.contratacao = contratacao;
	}
	
	
	
}
