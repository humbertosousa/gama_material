package br.com.unixyz.beans;

public class Turma {

	private String sigla;
	private String sala;
	private Curso curso;
	private Aluno aluno;
	private Professor professor;
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getSala() {
		return sala;
	}
	public void setSala(String sala) {
		this.sala = sala;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public Turma(String sigla, String sala, Curso curso, Aluno aluno, Professor professor) {
		super();
		this.sigla = sigla;
		this.sala = sala;
		this.curso = curso;
		this.aluno = aluno;
		this.professor = professor;
	}
	public Turma() {
		super();
	}
	@Override
	public String toString() {
		return "Turma [sigla=" + sigla + ", sala=" + sala + ", curso=" + curso + ", aluno=" + aluno + ", professor="
				+ professor + "]";
	}
	public void setAll(String sigla, String sala, Curso curso, Aluno aluno, Professor professor) {
		this.sigla = sigla;
		this.sala = sala;
		this.curso = curso;
		this.aluno = aluno;
		this.professor = professor;
	}
	
	
	
}
