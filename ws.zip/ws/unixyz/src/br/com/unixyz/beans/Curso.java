package br.com.unixyz.beans;

public class Curso {

	private String nome;
	private double valor;
	private String titulacao;
	private int duracao;
	public Curso(String nome, double valor, String titulacao, int duracao) {
		super();
		this.nome = nome;
		this.valor = valor;
		this.titulacao = titulacao;
		this.duracao = duracao;
	}
	public Curso() {
		super();
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getTitulacao() {
		return titulacao;
	}
	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	@Override
	public String toString() {
		return "Curso [nome=" + nome + ", valor=" + valor + ", titulacao=" + titulacao + ", duracao=" + duracao + "]";
	}
	public void setAll(String nome, double valor, String titulacao, int duracao) {
		this.nome = nome;
		this.valor = valor;
		this.titulacao = titulacao;
		this.duracao = duracao;
	}
	
	
	
	
}
