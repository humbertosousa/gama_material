package br.com.caicai.implementacao;

import br.com.caicai.modelo.Elevador;

public class TesteElevador {

	public static void main(String[] args) {
		
		Elevador objeto = new Elevador();
		
		objeto.inicializar("Torre B", (byte) 10, (byte) 20, (byte) 0); 
		
		System.out.println(objeto.subir());
		System.out.println(objeto.subir());
		System.out.println(objeto.descer());
		System.out.println(objeto.descer());
		System.out.println(objeto.descer());
		
		objeto.entrar((byte) 7);
		objeto.entrar();
		objeto.sair((byte) 5); 
		
		System.out.println(objeto.toString());
		
		
		
		
		
	}
	
	
	
}
