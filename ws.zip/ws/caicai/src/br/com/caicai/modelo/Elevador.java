package br.com.caicai.modelo;

public class Elevador {
	// <modificador> <tipo de retorno> <nome do metodo> (<tipo param> <nome param>, ...) {
	private String nome;
	private byte maximoPessoas;
	private byte andarMaximo;
	private byte andarMinimo;
	private byte andarAtual;
	private byte qtdePessoas;
	
	public void entrar() {
		if (qtdePessoas<maximoPessoas) {
			qtdePessoas++;
		}
	}
	
	public void entrar(byte pqtdePessoas) {
		if ((qtdePessoas+pqtdePessoas)<=maximoPessoas) {
			qtdePessoas+=pqtdePessoas; // qtdePessoas = qtdePessoas + pqtdePessoas
		}
	}
	
	public String descer() {
		if (andarAtual>andarMinimo) {
			andarAtual--;
			return "Descendo";
		}
		return "Voc� j� est� no andar m�nimo";
	}
	
	public String subir() {
		if (andarAtual<andarMaximo) {
			andarAtual++;
			return "Subindo";
		}
		return "Voc� j� est� no �ltimo andar!";
	}
	
	public void sair(byte pqtdePessoas) {
		if (pqtdePessoas<=qtdePessoas) {
			qtdePessoas-=pqtdePessoas; // qtdePessoas = qtdePessoas - pqtdePessoas
		}
	}
	
	public String toString() {
		return "Elevador [nome=" + nome + ", maximoPessoas=" + maximoPessoas + ", andarMaximo=" + andarMaximo
				+ ", andarMinimo=" + andarMinimo + ", andarAtual=" + andarAtual + ", qtdePessoas=" + qtdePessoas + "]";
	}

	public void inicializar(String pNome, byte pMaxPessoas, byte pAndarMax, byte pAndarMin) {
		nome = pNome;
		andarMaximo = pAndarMax;
		andarMinimo = pAndarMin;
		maximoPessoas=pMaxPessoas;
	}
	
	
}
