package br.com.bankofoz.principal;

import javax.swing.JOptionPane;

import br.com.bankofoz.beans.Agencia;
import br.com.bankofoz.beans.Cliente;
import br.com.bankofoz.beans.Conta;
import br.com.bankofoz.beans.Corrente;
import br.com.bankofoz.beans.Poupanca;

public class TesteConta {

	public static void main(String[] args) {

		Cliente cliente = new Cliente(
				1, "TIO PATINHAS", "tio@disney.com", "444444"
				);
		
		Agencia agencia = new Agencia();
		agencia.setAll("AGENCIA DO FUTURO", 789, "1234-5678");
		
		Conta conta = new Conta();
		
		char resposta = JOptionPane.showInputDialog
				("Digite\n<C> Corrente\n<P> Poupanca").toUpperCase().charAt(0);
		
		if (resposta=='C') {
			conta = new Corrente(123,500,cliente,agencia,1000,50);
		}else if (resposta=='P') {
			conta = new Poupanca(999,1000,cliente,agencia,5,"22/04/2021");
		}else {
			System.out.println("Tipo de conta inexistente");
		}
		
		System.out.println(conta.toString());
		System.out.println("Saldo : " + conta.getSaldo());
		conta.depositar(-100);
		conta.depositar(5000);
		System.out.println("Saldo: " + conta.getSaldo());
		conta.sacar(100000);
		conta.sacar(100);
		System.out.println("Saldo: " + conta.getSaldo());
		
		conta.creditarRendimento();
		conta.debitarTaxa();
		System.out.println(conta.getDiaAniversario());
		System.out.println("Atualizado: " + conta.getSaldo());
		/*
		if (conta instanceof Poupanca) {
			((Poupanca) conta).creditarRendimento();
			System.out.println(((Poupanca) conta).getDiaAniversario());
			System.out.println("Atualizado: " + conta.getSaldo());
		}else if (conta instanceof Corrente) {
			((Corrente) conta).debitarTaxa();
			System.out.println("Atualizado: " + conta.getSaldo());
		}
		*/
	}

}




