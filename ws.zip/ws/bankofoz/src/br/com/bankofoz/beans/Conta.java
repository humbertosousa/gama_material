package br.com.bankofoz.beans;
/*
 * Polimorfismo:
 * 
 *Quando um elemento possui o mesmo nome e a possibilidade de executar v�rias formas
 *M�todos:
 *- Override (sobrescrita): quando temos m�todos com o mesmo nome em classes diferentes 
 * (pai e filha) e que o m�todo da filha ter� prioridade sobre o pai.
 * - Overload (sobrecarga): quando os m�todos com o mesmo nome est�o na mesma classe, 
 * o que muda s�o os par�metros.
 * 
 * Objetos:
 * Ocorre quando voc� cria o objeto pelo pai e instancia pelo filho
 * Exemplo: Conta conta = new Corrente();
 */
import br.com.bankofoz.interfaces.PadraoConta;

public class Conta implements PadraoConta{

	private int numero;
	private double saldo;
	private Cliente cliente;
	private Agencia agencia;
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Agencia getAgencia() {
		return agencia;
	}
	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
	}
	public Conta(int numero, double saldo, Cliente cliente, Agencia agencia) {
		super();
		this.numero = numero;
		this.saldo = saldo;
		this.cliente = cliente;
		this.agencia = agencia;
	}
	public Conta() {
		super();
	}
	@Override
	public String toString() {
		return "Conta [numero=" + numero + ", saldo=" + saldo + ", cliente=" + cliente + ", agencia=" + agencia + "]";
	}
	public void setAll(int numero, double saldo, Cliente cliente, Agencia agencia) {
		this.numero = numero;
		this.saldo = saldo;
		this.cliente = cliente;
		this.agencia = agencia;
	}
	@Override
	public void sacar(double valor) {
		if (getSaldo()>=valor) {
			setSaldo(getSaldo()-valor);
		}
		
	}
	@Override
	public void depositar(double valor) {
		if (valor>0) {
			saldo+=valor;
		}
	}
	
	public void creditarRendimento() {}
	
	public void debitarTaxa() {}
	
	public String getDiaAniversario() {return null;}
	
	
}
