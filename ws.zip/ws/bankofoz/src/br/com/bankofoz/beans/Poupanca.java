package br.com.bankofoz.beans;

import br.com.bankofoz.interfaces.PadraoConta;

public class Poupanca extends Conta implements PadraoConta{

	private double rendimento;
	private String aniversario;
	
	public String getDiaAniversario() {
		if (aniversario.contains("/")) {
			return aniversario.substring(0, aniversario.indexOf("/"));
		}else if (aniversario.contains("-")) {
			return aniversario.substring(0, aniversario.indexOf("-"));
		}else {
			return "Data inv�lida";
		}
	}
	
	public void creditarRendimento() {
		super.setSaldo(super.getSaldo()+rendimento);
	}
	
	public double getRendimento() {
		return rendimento;
	}
	public void setRendimento(double rendimento) {
		this.rendimento = rendimento;
	}
	public String getAniversario() {
		return aniversario;
	}
	public void setAniversario(String aniversario) {
		this.aniversario = aniversario;
	}
	public Poupanca(int numero, double saldo, Cliente cliente, Agencia agencia, double rendimento, String aniversario) {
		super(numero, saldo, cliente, agencia);
		this.rendimento = rendimento;
		this.aniversario = aniversario;
	}
	public Poupanca() {
		super();
	}
	@Override
	public String toString() {
		return "Poupanca [rendimento=" + rendimento + ", aniversario=" + aniversario + ", toString()="
				+ super.toString() + "]";
	}
	public void setAll(int numero, double saldo, Cliente cliente, Agencia agencia, double rendimento, String aniversario) {
		super.setAll(numero, saldo, cliente, agencia);
		this.rendimento = rendimento;
		this.aniversario = aniversario;
	}
	@Override
	public void sacar(double valor) {
		if (super.getSaldo()>=valor) {
			super.setSaldo(super.getSaldo()-valor);
		}
		
	}
	@Override
	public void depositar(double valor) {
		if (valor>0) {
			super.setSaldo(super.getSaldo()+valor);
		}
		
	}
	
	public double getSaldo() {
		return super.getSaldo();
	}
	
	
}
