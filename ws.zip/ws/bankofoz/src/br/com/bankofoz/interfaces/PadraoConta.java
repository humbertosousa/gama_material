package br.com.bankofoz.interfaces;

public interface PadraoConta {

	public double getSaldo();
	public void sacar(double valor);
	public void depositar(double valor);
	
}
