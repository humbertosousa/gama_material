package br.com.rubinhocar.implementacao;

import br.com.rubinhocar.modelo.Veiculo;

public class TesteVeiculo {

	
	public static void main(String[] args) {
		//instancia um objeto
		
		Veiculo objeto = new Veiculo();
		objeto.preencherModelo("camaro");
		objeto.preencherCor("amarelo");
		objeto.preencherBasico(200000, 300);
		System.out.println(objeto.ligar());
		objeto.acelerar(20);
		objeto.acelerar(20);
		objeto.acelerar(20);
		System.out.println(objeto.retornarTudo());
		
		System.out.println(objeto.desligar());
		System.out.println(objeto.retornarTudo());
		
		
		
		
		
		 
		
		
		
		
	}
	
	
}
