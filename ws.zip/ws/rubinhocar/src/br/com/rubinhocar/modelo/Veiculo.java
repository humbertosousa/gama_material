package br.com.rubinhocar.modelo;

public class Veiculo {
	// <modificador> <tipo de retorno> <nome do m�todo>(<tipo param> <nome do param>) {
	private String modelo;
	private float valor;
	private String cor;
	private boolean status;
	private int velocidadeMaxima;
	private int velocidadeAtual;
	
	public void acelerar(int velocidade) {
		if (status==true) {
			velocidadeAtual += velocidade;
		}
	}
	
	public String desligar() {
		status = false;
		velocidadeAtual=0;
		return "Veiculo desligado";
	}
	
	public String ligar() {
		status=true;
		return "Veiculo Ligado";
	}
	
	public String retornarResumo() {
		String apoio = "LIGADO";
		if (status == false) {
			apoio = "DESLIGADO";
		}
		return 
				"Modelo...............: " + modelo + "\n" + 
				"Status...............: " + apoio + "\n" + 
				"Velocidade M�xima....: " + velocidadeMaxima + "\n" + 
				"Velocidade Atual.....: " + velocidadeAtual;
	}
	
	
	public String retornarTudo() {
		String apoio = "LIGADO";
		if (status == false) {
			apoio = "DESLIGADO";
		}
		return 
				"Modelo...............: " + modelo + "\n" + 
				"Valor................: " + valor + "\n" + 
				"Cor..................: " + cor + "\n" + 
				"Status...............: " + apoio + "\n" + 
				"Velocidade M�xima....: " + velocidadeMaxima + "\n" + 
				"Velocidade Atual.....: " + velocidadeAtual;
	}
	
	public void preencherBasico(float pValor, int pVelocidadeMaxima) {
		valor=pValor;
		velocidadeMaxima=pVelocidadeMaxima;
	}
	
	public String retornarCor() {
		return cor;
	}
	
	public void preencherCor(String param) {
		if (param.length()<=15) {
			cor=param.toUpperCase();
		}
	}
	
	public String retornarModelo() {
		return modelo;
	}
	
	public void preencherModelo(String param) {
		if (param.length()<31) {
			modelo = param.toUpperCase();
		}
	
	}
	
	
	
	
}
