# turma10c
Projetos desenvolvidos em Java 8, nas distribuições SE e EE.

Este repositório contém uma workspace preparada na ide Eclipse 2020.

Comentário feito no git local.

Segunda alteração no git remoto.
