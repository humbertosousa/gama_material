package br.com.unixyz.modelo;

import br.com.unixyz.padroes.PadraoFormacao;

public class Pos  implements PadraoFormacao{

	public void calcMensalidade(double fator) {
		// TODO Auto-generated method stub
		
	}

	public String getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean add() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}






	
	
}
