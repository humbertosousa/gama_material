package br.com.unixyz.padroes;

public interface PadraoFormacao {

	void calcMensalidade(double fator);
	String getAll();
	boolean add();
	int delete(int id);
	
}
