package br.com.unixyz.modelo;

import br.com.unixyz.padroes.PadraoFormacao;

public class Pos  implements PadraoFormacao{

	@Override
	public void calcMensalidade(double fator) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}






	
	
}
