package interfaces;

public interface Padrao {

	public float verificarSaldo();
	
	
}
