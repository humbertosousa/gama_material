package br.com.bankofoz.beans;

import interfaces.Padrao;

public class Salario implements Padrao{

	
	@Override
	public float verificarSaldo() {
		// TODO Auto-generated method stub
		return 0;
	}

}
