package br.com.excecoes.implementacao;

public class ExemploGit {

	public static void main(String[] args) {
		System.out.println("oi");
	}

}
