package br.com.votacao.beans;

public class Voto {
	private Pessoa candidato;
	private Pessoa eleitor;
	private boolean primeiroTurno;
	
	public Pessoa getCandidato() {
		return candidato;
	}
	public void setCandidato(Pessoa candidato) {
		this.candidato = candidato;
	}
	public Pessoa getEleitor() {
		return eleitor;
	}
	public void setEleitor(Pessoa eleitor) {
		this.eleitor = eleitor;
	}
	public boolean isPrimeiroTurno() {
		return primeiroTurno;
	}
	public void setPrimeiroTurno(boolean primeiroTurno) {
		this.primeiroTurno = primeiroTurno;
	}
	public Voto(Pessoa candidato, Pessoa eleitor, boolean primeiroTurno) {
		super();
		this.candidato = candidato;
		this.eleitor = eleitor;
		this.primeiroTurno = primeiroTurno;
	}
	public Voto() {
		super();
	}
	public void setAll(Pessoa candidato, Pessoa eleitor, boolean primeiroTurno) {
		this.candidato = candidato;
		this.eleitor = eleitor;
		this.primeiroTurno = primeiroTurno;
	}
	@Override
	public String toString() {
		return "Voto [candidato=" + candidato + ", eleitor=" + eleitor + ", primeiroTurno=" + primeiroTurno + "]";
	}

}
