# wsremoto_humberto
Uma workspace com projetos em Java.

Para montagem da Workspace utilizei o Eclipse 2020.
Os projetos estão em Java SE 1.8
Todos os projetos são exemplos voltados ao paradigma de Orientação à Objetos.
