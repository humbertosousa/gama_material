package variaveis;

public class Itau {

	
	// main � o start-point da aplica��o
	/*
	 * Uma classe em Java sempre come�a com maiuscula
	 * Um m�todo sempre vem seguido de parenteses
	 * 
	 */
public static void main(String[] args) { // main � o metodo principal
	
	
	System.out.println("Ol� Mundo");




}	





}
