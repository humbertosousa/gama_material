function filtrardatas(){

    fetch("http://localhost:8080/relatorio/" + 
    document.getElementById("txtinicio").value + "/" + 
    document.getElementById("txttermino").value)
        .then(res => res.json())
        .then(res => {
            var tabela="<table class='table' border='1' align='center'><tr><th>Musica</th><th>Cadastro</th><th>Código</th></tr>";
            for (contador=0;contador<res.length;contador++){
                tabela+=
                    "<tr>" +
                    "<td>" + res[contador].titulo + "</td>" +
                    "<td>" + res[contador].cadastro + "</td>" +
                    "<td>" + res[contador].id + "</td>" +
                    "</tr>";
            }
            tabela+="</table>";
            document.getElementById("tabela").innerHTML=tabela;
        })
        .catch(err =>{
            window.alert("Músicas não encontradas");
            var tabela="<table class='table' border='1' align='center'><tr><th>Musica</th><th>Cadastro</th><th>Código</th></tr>";
            tabela+="</table>";
            document.getElementById("tabela").innerHTML=tabela;
        });
}

function exibirartistas(){

    fetch("http://localhost:8080/artistas")
        .then(res => res.json())
        .then(res => {
            var artistas = "";
            for(contador=0;contador<res.length;contador++){
                artistas+="<option value='"+res[contador].id+"'>"+res[contador].nomeArtistico+"</option>"; 
            }
            document.getElementById("cmbartistas").innerHTML=artistas;
        })
        .catch()

}


function filtrar(){

    fetch("http://localhost:8080/artista/" + document.getElementById("cmbartistas").value)
        .then(res => res.json())
        .then(res => {
            var tabela="<table class='table' border='1' align='center'><tr><th>Musica</th><th>Cadastro</th><th>Código</th></tr>";
            for (contador=0;contador<res.musicas.length;contador++){
                tabela+=
                    "<tr>" +
                    "<td>" + res.musicas[contador].titulo + "</td>" +
                    "<td>" + res.musicas[contador].cadastro + "</td>" +
                    "<td>" + res.musicas[contador].id + "</td>" +
                    "</tr>";
            }
            tabela+="</table>";
            document.getElementById("tabela").innerHTML=tabela;
        })
        .catch()

}