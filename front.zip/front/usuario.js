function exibirusuario(){
    var usuariostr = localStorage.getItem("usuariologado");
    if (usuariostr==null){
        window.location="login.html";
    }else{
        var usuariojson = JSON.parse(usuariostr);
        document.getElementById("dados").innerHTML = 
        "<h3>" + usuariojson.nome + "<br>" + 
        usuariojson.email + "<br>Código: " + usuariojson.id + "</h3>" ;
        document.getElementById("foto").innerHTML = 
        "<img alt='Foto do Usuario' width='20%' src=imagens/" + usuariojson.foto + ">";

    }

}

function gravar(){
    var carta = {
        email : document.getElementById("txtemail").value ,
        senha : document.getElementById("txtsenha").value ,
        foto : document.getElementById("txtfoto").value ,
        nome : document.getElementById("txtnome").value 
    }

    var envelope = {
        method : "POST",
        body : JSON.stringify(carta),
        headers : {
            "Content-type" : "application/json"
        }
    };

    fetch("http://localhost:8080/novousuario", envelope)
        .then(res => res.json())
        .then(res => {
            window.alert("Usuário " + res.id + " gravado com sucesso");
            window.location="novousuario.html";
        })
        .catch(err => {
            window.alert("Não foi possível realizar a gravação");
        });

}


function logar(){
    var carta = {
        email : document.getElementById("txtemail").value ,
        senha : document.getElementById("txtsenha").value
    };
    var envelope = {
        method : "POST",
        body : JSON.stringify(carta),
        headers : {
            "Content-type" : "application/json"
        }
    };
    fetch("http://localhost:8080/login", envelope)
        .then(res => res.json())
        .then(res => {
            window.alert("Login realizado!");
            localStorage.setItem("usuariologado", JSON.stringify(res));
            window.location = "usuario.html";
        })
        .catch(err => {
            window.alert("Deu ruim");
        });
}

function logarGet(){
    fetch("http://localhost:8080/consulta/" + 
    document.getElementById("txtemail").value + "/" + 
    document.getElementById("txtsenha").value)
        .then(res => res.json())
        .then(res => {
            window.alert("Login realizado!");
            window.location = "usuario.html";
        })
        .catch(err => {
            window.alert("Deu ruim");
        });
}